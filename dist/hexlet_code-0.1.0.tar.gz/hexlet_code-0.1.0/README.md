### Hexlet tests and linter status:
[![Actions Status](https://github.com/gromniki/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/gromniki/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/ee618c52bcc8f6531632/maintainability)](https://codeclimate.com/github/gromniki/python-project-49/maintainability)
